Version 1.0.86.2
Date: June 12 2019
 * Fix bugs only

Version 1.0.86
Date: April 15 2019
 * Add mobilpay and paystack gateway.

Version 1.0.84
Date: Jan 19 2019
 * Allow attach file in private message.
 * Live notification added.
 * Allow add avatar field in singup
 * Add language for captcha.
 * Allow show one column layout in list profiles pages
 * Add categories block in home page.
 * Fixed install sample data.
 * Fixed stripe in deposit credit page.

Version 1.0.83
Date: Nov 28 2018
 * Fix minor bug.
 * Fix  profile is hidden in home page.
 * Allow to show map on archive profile page.

Version 1.0.82
Date: Nov 09 2018
 * Hot fix

Version 1.0.81
Date: Nov 07 2018
 * Bug fixes

Version 1.0.80
Date: Nov 01 2018
 * Add direct message option
 * Add invite bid job
 * Bug fixes

Version 1.0.79
Date: Oct 26 2018
 * Add Stripe Payment gateway
 * Correct dashboard switch button.
 * Improve layout in checkout

Version 1.0.78
Date: Oct 23 2018
 * Fixed Bid Price.
 * Fix mail cash payment.
 * Hidden publish button in dashboard of order detail.
 * Improve notification.
 * Add button switch role.

Version 1.0.77
Date: Sep 19 2018

* Fix mobile css
* Fix  shortcode list project.
* Fix pagination.


Version 1.0.76
Date: Sep 15 2018

* Add option to disable confirmation step after register.
* Fixed Map missing.
* Fixed Subscription checkout link.

Version 1.0.751
Date: Sep 11 2018

* Hot fix few minor issues.

Version 1.0.75
Date: Sep 09 2018

* Add verify function.

Version 1.0.74
Date: Aug 27 2018
* Add dashboard page
* Add my bidding page.
* Correct dashboard page
* Fix notifcation status.
* Fix subscription time.
* Improve post project form- validate.
* Improve responsive mobile.
* Modify list page default.
* Update .po languages files.

Version 1.0.73
Date: Aug 06  2018
* Correct map API
* Update some text in .po file.


Version 1.0.72
Date: Aug 01  2018
* Fix map problem.

-----------------------------------------
Version 1.0.71
Date: June 14  2018
* Fix register in mobile
* Fix Membership layout
* Fix paganition
* Update translate

Version 1.0.6
Date: March 30 2018
* Improve My Credit view.
* Improve database struct and ux/ui of withdrawal post.
* Improve auto generator default page and tool to set page.
* Update sample data in .xml file.

Version 1.0.5
Date: March 18 2018
* Improve My Credit view.
* Add nearby map featured.
* Fix minor issues