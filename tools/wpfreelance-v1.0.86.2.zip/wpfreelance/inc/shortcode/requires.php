<?php
require get_parent_theme_file_path( '/inc/shortcode/shortcode.php');
require get_parent_theme_file_path( '/inc/shortcode/shortcode_membership.php');
