<?php
require get_parent_theme_file_path( '/inc/plugins/acf.php');
