( function( $ ) {
	$(document).ready(function(){
		var  packages =JSON.parse( jQuery('#json_packages').html() );


	});
})( jQuery, window.ajaxSend );