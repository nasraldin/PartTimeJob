  <li>
    <div class="cs-media">
        <figure>
            <a href="http://jobcareer.chimpgroup.com/candidate/candidate-demo/">
                <img src="http://jobcareer.chimpgroup.com/wp-content/uploads/wp-jobhunt-users/candidate25-200x200.jpg" alt="">
            </a>
        </figure>
    </div>
    <div class="cs-text">
        <div class="cs-post-title">
            <h5><a href="http://jobcareer.chimpgroup.com/candidate/candidate-demo/">TEst ETst</a> <span class="cs-location cs-color">london</span></h5>
        </div>
        <div class="post-option">
            <span class="cs-min-salary">$50000 p.a minimum</span>                                <span class="cs-post-date">Last Activity 13 mins ago</span>
                                    </div>
        <span><a class="cs-color">IT Contractor</a></span>                    </div>
    <div class="cs-uploaded jobseeker-detail">
        <span class="cs-btn-holder">
        <a data-toggle="tooltip" data-placement="top" title="" class="ad_to_short_list add_list_icon cs-button" id="cs_empl_check_321" data-id="321" data-original-title="Shortlist"><i class="icon-plus-circle"></i>Shortlist</a>
                                        </span>
    </div>
</li>

  <li>
    <div class="cs-media">
        <figure>
            <a href="http://jobcareer.chimpgroup.com/candidate/candidate-demo/">
                <img src="http://jobcareer.chimpgroup.com/wp-content/uploads/wp-jobhunt-users/candidate25-200x200.jpg" alt="">
            </a>
        </figure>
    </div>
    <div class="cs-text">
        <div class="cs-post-title">
            <h5><a href="http://jobcareer.chimpgroup.com/candidate/candidate-demo/">TEst ETst</a> <span class="cs-location cs-color">london</span></h5>
        </div>
        <div class="post-option">
            <span class="cs-min-salary">$50000 p.a minimum</span>                                <span class="cs-post-date">Last Activity 13 mins ago</span>
                                    </div>
        <span><a class="cs-color">IT Contractor</a></span>                    </div>
    <div class="cs-uploaded jobseeker-detail">
        <span class="cs-btn-holder">
        <a data-toggle="tooltip" data-placement="top" title="" class="ad_to_short_list add_list_icon cs-button" id="cs_empl_check_321" data-id="321" data-original-title="Shortlist"><i class="icon-plus-circle"></i>Shortlist</a>
                                        </span>
    </div>
</li>

  <li>
    <div class="cs-media">
        <figure>
            <a href="http://jobcareer.chimpgroup.com/candidate/candidate-demo/">
                <img src="http://jobcareer.chimpgroup.com/wp-content/uploads/wp-jobhunt-users/candidate25-200x200.jpg" alt="">
            </a>
        </figure>
    </div>
    <div class="cs-text">
        <div class="cs-post-title">
            <h5><a href="http://jobcareer.chimpgroup.com/candidate/candidate-demo/">TEst ETst</a> <span class="cs-location cs-color">london</span></h5>
        </div>
        <div class="post-option">
            <span class="cs-min-salary">$50000 p.a minimum</span>                                <span class="cs-post-date">Last Activity 13 mins ago</span>
                                    </div>
        <span><a class="cs-color">IT Contractor</a></span>                    </div>
    <div class="cs-uploaded jobseeker-detail">
        <span class="cs-btn-holder">
        <a data-toggle="tooltip" data-placement="top" title="" class="ad_to_short_list add_list_icon cs-button" id="cs_empl_check_321" data-id="321" data-original-title="Shortlist"><i class="icon-plus-circle"></i>Shortlist</a>
                                        </span>
    </div>
</li>
